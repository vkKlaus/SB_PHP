    <footer>
         <!-- выводим вертикальное меню сформированное по убыванию пунктов -->
        <?= createMenu('dsc', 'vertical') ?>
        <!-- выводим  copy-right -->
        <hr>
        <div class="copy-right">&copy;&nbsp;<nobr>2018</nobr> Project.</div>
    </footer>
</body>

</html>