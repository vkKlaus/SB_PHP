 <div class="page">
        <h1 class="page-header"> <?= $pageTitle ?> </h1>   
        <p> вы находитесь по адресу: <?= $url ?></p>
    </div>