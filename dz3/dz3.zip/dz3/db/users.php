<?php
    $users = [
        ['id' => 0,
        'name'=> 'Пользователь1 с id 0',
        'email' => 'user1@db.com',
        ],

        ['id' => 1,
        'name'=> 'Пользователь2 с id 1',
        'email' => 'user2@db.com',
        ],

        ['id' => 2,
        'name'=> 'Пользователь3 с id 2',
        'email' => 'user3@db.com',
        ],

        ['id' => 3,
        'name'=> 'Пользователь4 с id 3',
        'email' => 'user4@db.com',
        ],

        ['id' => 4,
        'name'=> 'Пользователь5 с id 4',
        'email' => 'user5@db.com',
        ],


    ];

?>

