<?php
    $userPaswords = [
        ['id' => 0,
        'email' => 'user1@db.com',
        'password' => '000',
        ],

        ['id' => 1,
        'email' => 'user2@db.com',
        'password' => '111',
        ],

        ['id' => 2,
        'email' => 'user3@db.com',
        'password' => '222',
        ],

        ['id' => 3,
        'email' => 'user4@db.com',
        'password' => '333',
        ],

        ['id' => 4,
        'email' => 'user5@db.com',
        'password' => '444',
        ],


    ];
