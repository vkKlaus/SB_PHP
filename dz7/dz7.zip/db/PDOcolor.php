<?php
$colors = [
    [
        'id' => 1,
        'name' => 'красный',
        'red' => 255,
        'green' => 0,
        'blue' => 0
    ],
    [
        'id' => 2,
        'name' => 'зеленый',
        'red' => 0,
        'green' => 255,
        'blue' => 0
    ],
    [
        'id' => 3,
        'name' => 'синий',
        'red' => 0,
        'green' => 0,
        'blue' => 255
    ],
    [
        'id' => 4,
        'name' => 'белый',
        'red' => 255,
        'green' => 255,
        'blue' => 255
    ],
    [
        'id' => 5,
        'name' => 'черный',
        'red' => 0,
        'green' => 0,
        'blue' => 0
    ],
    [
        'id' => 6,
        'name' => 'серый',
        'red' => 200,
        'green' => 200,
        'blue' => 200
    ],

];
