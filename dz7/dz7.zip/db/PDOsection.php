<?php
  $sections = [
    [
        'id' => 1,
        'name' => 'Основные',
        'parent_id' => 0,
        'user_id' => 2,
        'color_id' => 3
    ],
    [
        'id' => 2,
        'name' => 'по работе',
        'parent_id' => 1,
        'user_id' => 2,
        'color_id' => 3
    ],
    [
        'id' => 3,
        'name' => 'личные',
        'parent_id' => 1,
        'user_id' => 2,
        'color_id' => 3
    ],
    [
        'id' => 4,
        'name' => 'Оповещения',
        'parent_id' => 0,
        'user_id' => 3,
        'color_id' => 4
    ],
    [
        'id' => 5,
        'name' => 'форумы',
        'parent_id' => 4,
        'user_id' => 3,
        'color_id' => 4
    ],
    [
        'id' => 6,
        'name' => 'кино',
        'parent_id' => 5,
        'user_id' => 3,
        'color_id' => 4
    ], [
        'id' => 7,
        'name' => 'игры',
        'parent_id' => 5,
        'user_id' => 3,
        'color_id' => 4
    ],
    [
        'id' => 8,
        'name' => 'магазины',
        'parent_id' => 4,
        'user_id' => 3,
        'color_id' => 4
    ],
    [
        'id' => 9,
        'name' => 'подписки',
        'parent_id' => 4,
        'user_id' => 3,
        'color_id' => 4
    ],
    [
        'id' => 10,
        'name' => 'Спам',
        'parent_id' => 0,
        'user_id' => 5,
        'color_id' => 5
    ],

];