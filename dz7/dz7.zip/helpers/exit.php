<?php
echo '<script>window.location.href = "/"</script>';
