<li class="enter-menu-element horizontal-menu-element <?= $recov ? 'active-enter' : '' ?>">
    <a href="/route/enter/?enter=recov" class="enter-menu-link horizontal-menu-link ">
        <div class="enter-menu-title ">Забыли пароль?</div>
    </a>
</li>