
-- --------------------------------------------------------

--
-- Структура таблицы `main_menu`
--

DROP TABLE IF EXISTS `main_menu`;
CREATE TABLE `main_menu` (
  `id` int(3) NOT NULL,
  `title` varchar(50) NOT NULL,
  `path` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Очистить таблицу перед добавлением данных `main_menu`
--

TRUNCATE TABLE `main_menu`;
--
-- Дамп данных таблицы `main_menu`
--

INSERT INTO `main_menu` VALUES
(1, 'Главная', '/'),
(100, 'О нас', '/route/about/'),
(200, 'Новости', '/route/news/'),
(300, 'Каталог', '/route/catalog/'),
(400, 'Контакты для связи', '/route/contact/'),
(500, 'Галерея', '/route/images/'),
(600, 'Профиль пользователя', '/route/user/'),
(999, 'Админ', '/route/admin/');
