
-- --------------------------------------------------------

--
-- Структура таблицы `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(3) NOT NULL,
  `name` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Очистить таблицу перед добавлением данных `roles`
--

TRUNCATE TABLE `roles`;
--
-- Дамп данных таблицы `roles`
--

INSERT INTO `roles` VALUES
(999, 'Администратор');
