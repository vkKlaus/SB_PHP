
-- --------------------------------------------------------

--
-- Структура таблицы `group_user`
--

DROP TABLE IF EXISTS `group_user`;
CREATE TABLE `group_user` (
  `user_id` int(10) NOT NULL,
  `group_id` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Очистить таблицу перед добавлением данных `group_user`
--

TRUNCATE TABLE `group_user`;