
-- --------------------------------------------------------

--
-- Структура таблицы `section`
--

DROP TABLE IF EXISTS `section`;
CREATE TABLE `section` (
  `id` int(3) NOT NULL,
  `title` varchar(50) NOT NULL,
  `parent_id` int(3) DEFAULT NULL,
  `user_id` int(10) NOT NULL,
  `color_id` int(3) DEFAULT NULL,
  `date_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Очистить таблицу перед добавлением данных `section`
--

TRUNCATE TABLE `section`;