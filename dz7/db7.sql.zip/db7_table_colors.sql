
-- --------------------------------------------------------

--
-- Структура таблицы `colors`
--

DROP TABLE IF EXISTS `colors`;
CREATE TABLE `colors` (
  `id` int(3) NOT NULL,
  `name` varchar(45) NOT NULL,
  `red` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `green` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `blue` tinyint(3) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Очистить таблицу перед добавлением данных `colors`
--

TRUNCATE TABLE `colors`;
--
-- Дамп данных таблицы `colors`
--

INSERT INTO `colors` VALUES
(1, 'красный', 255, 0, 0),
(2, 'зеленый', 0, 255, 0),
(3, 'синисй', 0, 0, 255);
