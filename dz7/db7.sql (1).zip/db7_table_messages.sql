
-- --------------------------------------------------------

--
-- Структура таблицы `messages`
--

CREATE TABLE `messages` (
  `id` int(10) NOT NULL,
  `title` varchar(1024) NOT NULL,
  `date_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `text` text,
  `user_id_sender` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
