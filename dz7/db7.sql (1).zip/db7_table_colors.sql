
-- --------------------------------------------------------

--
-- Структура таблицы `colors`
--

CREATE TABLE `colors` (
  `id` int(3) NOT NULL,
  `name` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `red` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `green` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `blue` tinyint(3) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `colors`
--

INSERT INTO `colors` (`id`, `name`, `red`, `green`, `blue`) VALUES
(1, 'красный', 255, 0, 0),
(2, 'зеленый', 0, 255, 0),
(3, 'синий', 0, 0, 255),
(4, 'белый', 255, 255, 255),
(5, 'черный', 0, 0, 0),
(6, 'серый', 200, 200, 200);
