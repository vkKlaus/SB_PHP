
-- --------------------------------------------------------

--
-- Структура таблицы `main_menu`
--

CREATE TABLE `main_menu` (
  `id` int(3) NOT NULL,
  `title` varchar(50) NOT NULL,
  `path` varchar(255) NOT NULL,
  `usePanel` tinyint(1) NOT NULL DEFAULT '0',
  `adm_panel` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `main_menu`
--

INSERT INTO `main_menu` (`id`, `title`, `path`, `usePanel`, `adm_panel`) VALUES
(1, 'Главная', '/', 1, 0),
(100, 'О нас', '/route/about/', 0, 0),
(200, 'Новости', '/route/news/', 0, 0),
(300, 'Каталог', '/route/catalog/', 0, 0),
(400, 'Контакты для связи', '/route/contact/', 0, 0),
(500, 'Галерея', '/route/images/', 0, 0),
(550, 'Сообщения', '/route/messages/', 1, 0),
(570, 'Разделы', '/route/sections/', 1, 0),
(600, 'Профиль ', '/route/user/', 1, 0),
(999, 'Админ', '/route/admin/', 1, 1);
