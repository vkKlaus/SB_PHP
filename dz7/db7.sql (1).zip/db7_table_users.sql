
-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password` char(60) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `flag_email_notification` tinyint(1) NOT NULL DEFAULT '0',
  `flag_active` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `user`, `email`, `phone`, `password`, `flag_email_notification`, `flag_active`) VALUES
(1, 'admin', 'admin@adm.dz7', '000-00-00', '$2y$10$N7irlIffhiVj9CsAzcP9jOnliI9nFDRDkVenhicWa6k0tMr6aB3jS', 1, 0),
(2, 'us10', 'us1@1.dz7', '111 - 11 - 11', '$2y$10$TPKLV3/XHLDp2NtS8EnWJukg49BSqtj.HBM.idiX2CO9ZNt3.F1se', 1, 0),
(3, 'us20', 'us2@2.dz7', '222 - 22 - 22', '$2y$10$u2LJ0ieYbsuBDjjONLzfT.CNfCF4A9hLdX/QEJQCnAs9NPgDnZvpW', 1, 0),
(4, 'us30', 'us3@3.dz7', '333 - 33 - 33', '$2y$10$kDg7ptjyTG0WhEYUtmCOGeUapOkU2kq/OkePNq3SUY6uBcVHBSpiu', 1, 0),
(5, 'us40', 'us4@4.dz7', '444 - 44 - 44', '$2y$10$MN4YCkw6CsW6gWNbzeWssOcK/xLbWL49XB5NbI33SyfxZ.JeG.dnW', 1, 0),
(6, 'us50', 'us5@5.dz7', '555 - 55 - 55', '$2y$10$RrlDPpY829yxpeiCTJ5v/OJYWMTlLWoszOYrdyQR5tIfpi0rMNLGa', 1, 0),
(7, 'us60', 'us6@6.dz7', '666 - 66 - 66', '$2y$10$cHlw1AB.Yw6f.CfEC/6Hsu2XdnYt0Eifz6iPaXt1lMa5L.XAL9Wbu', 1, 0),
(8, 'us70', 'us7@7.dz7', '777 - 77 - 77', '$2y$10$q4YWJXXNcZfsGMMpfZ3LPexH.NZPAH0JUTHoM2KdLdIL/XCaRVa8q', 1, 0),
(9, 'us80', 'us8@8.dz7', '888 - 88 - 88', '$2y$10$WENXkZe0sQNx5ui2oqJ.FegbTeAI9Qd21Nojs9V8Jd0dOgoO1JwJW', 1, 0),
(10, 'us90', 'us9@9.dz7', '999 - 99 - 99', '$2y$10$4rA7.DqxjR4IJS.YKfxUiuPKT6v93dmg0jWybQbVKBj6ntMoMreU.', 1, 0);
