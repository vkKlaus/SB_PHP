
-- --------------------------------------------------------

--
-- Структура таблицы `sections`
--

CREATE TABLE `sections` (
  `id` int(3) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `parent_id` int(3) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL,
  `color_id` int(3) DEFAULT NULL,
  `date_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `sections`
--

INSERT INTO `sections` (`id`, `name`, `parent_id`, `user_id`, `color_id`) VALUES
(1, 'Основные', 0, 2, 3),
(2, 'по работе', 1, 2, 3),
(3, 'личные', 1, 2, 3),
(4, 'Оповещения', 0, 3, 4),
(5, 'форумы', 4, 3, 4),
(6, 'кино', 5, 3, 4),
(7, 'игры', 5, 3, 4),
(8, 'магазины', 4, 3, 4),
(9, 'подписки', 4, 3, 4),
(10, 'Спам', 0, 5, 5),
(40, 'ыыыы', 5, 1, 1),
(41, 'ddd', 40, 1, 2);
