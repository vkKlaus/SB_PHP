
-- --------------------------------------------------------

--
-- Структура таблицы `message_recipient`
--

CREATE TABLE `message_recipient` (
  `message_id` int(10) NOT NULL,
  `recipient_user_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
