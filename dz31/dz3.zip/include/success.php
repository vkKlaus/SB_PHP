<h3 class="findUser">Авторизация прошла успешно</h3>
<p class="errorUser">пользователь: <?= $login ?></p>