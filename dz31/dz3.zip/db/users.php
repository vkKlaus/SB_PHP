﻿<?php
    $users = [ 
        'user1@db.com',
        'user2@db.com',
        'user3@db.com',
        'user4@db.com',
        'user5@db.com',
    ];


