    <footer>
         <!-- выводим вертикальное меню сформированное по убыванию пунктов -->
        <?php createMenu($mainMenu,'dsc', 'vertical') ?>
        <!-- выводим  copy-right -->
        <hr>
        <div class="copy-right">&copy;&nbsp;<nobr>2018</nobr> Project.</div>
    </footer>

    <script src="/js/jquery-3.3.1.min.js"></script>
    <script src="/js/jquery.fancybox.min.js"></script>

</body>

</html>