<li class="enter-menu-element horizontal-menu-element <?= $autor ? 'active-enter' : '' ?>">
    <a href="/route/enter/?enter=autor" class="enter-menu-link horizontal-menu-link ">
        <div class="enter-menu-title ">Авторизация</div>
    </a>
</li>