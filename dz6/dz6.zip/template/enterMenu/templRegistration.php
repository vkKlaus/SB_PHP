<li class="enter-menu-element horizontal-menu-element <?= $regis ? 'active-enter' : '' ?>">
    <a href="/route/enter/?enter=regis" class="enter-menu-link horizontal-menu-link ">
        <div class="enter-menu-title ">Регистрация</div>
    </a>
</li>