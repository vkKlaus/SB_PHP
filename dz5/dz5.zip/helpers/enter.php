<?php
existFileEnter();

require $_SERVER['DOCUMENT_ROOT'] . '/db/users.php';
require $_SERVER['DOCUMENT_ROOT'] . '/db/usersPs.php';

var_dump($users);
var_dump($userPaswords);
