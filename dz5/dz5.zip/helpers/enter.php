<?php
existFileEnter();

require $_SERVER['DOCUMENT_ROOT'] . '/db/users.php';
require $_SERVER['DOCUMENT_ROOT'] . '/db/usersPs.php';
